/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.entity;

/**
 *
 * @author User
 */
public class Booking {
    private int id;
    private Schedule schedule;
    private User user;
    private int noOfAdults;
    private int noOfChildrens;
    private int status;

    public Booking() {
    }

    public Booking(int id, Schedule schedule, User user, int noOfAdults, int noOfChildrens, int status) {
        this.id = id;
        this.schedule = schedule;
        this.user = user;
        this.noOfAdults = noOfAdults;
        this.noOfChildrens = noOfChildrens;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getNoOfAdults() {
        return noOfAdults;
    }

    public void setNoOfAdults(int noOfAdults) {
        this.noOfAdults = noOfAdults;
    }

    public int getNoOfChildrens() {
        return noOfChildrens;
    }

    public void setNoOfChildrens(int noOfChildrens) {
        this.noOfChildrens = noOfChildrens;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
    
}
