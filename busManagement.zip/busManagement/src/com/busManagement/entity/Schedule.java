/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.entity;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author User
 */
public class Schedule {
    private int id;
    private Bus bus;
    private Location source;
    private Location destination;
    private int travelDuration;
    private String description;
    private LocalDate date;
    private LocalTime time;
    private double fare;
    private int available;

    public Schedule() {
    }

    public Schedule(int id, Bus bus, Location source, Location destination, int travelDuration, String description, LocalDate date, LocalTime time, double fare, int available) {
        this.id = id;
        this.bus = bus;
        this.source = source;
        this.destination = destination;
        this.travelDuration = travelDuration;
        this.description = description;
        this.date = date;
        this.time = time;
        this.fare = fare;
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Bus getBus() {
        return bus;
    }

    public void setBus(Bus bus) {
        this.bus = bus;
    }

    public Location getSource() {
        return source;
    }

    public void setSource(Location source) {
        this.source = source;
    }

    public Location getDestination() {
        return destination;
    }

    public void setDestination(Location destination) {
        this.destination = destination;
    }

    public int getTravelDuration() {
        return travelDuration;
    }

    public void setTravelDuration(int travelDuration) {
        this.travelDuration = travelDuration;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getTime() {
        return time;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }

    public double getFare() {
        return fare;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

    public int getAvailable() {
        return available;
    }

    public void setAvailable(int available) {
        this.available = available;
    }
    
    
}
