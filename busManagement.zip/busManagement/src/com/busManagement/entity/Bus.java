/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.entity;

import java.awt.image.BufferedImage;

/**
 *
 * @author User
 */
public class Bus {
    private int id;
    private String name;
    private String type;
    private Company company;
    private BufferedImage busImage;
    private int totalSeats;
    private int availableSeats;

    public Bus() {
    }

    public Bus(int id, String name, String type, Company company, BufferedImage busImage, int totalSeats, int availableSeats) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.company = company;
        this.busImage = busImage;
        this.totalSeats = totalSeats;
        this.availableSeats = availableSeats;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public BufferedImage getBusImage() {
        return busImage;
    }

    public void setBusImage(BufferedImage busImage) {
        this.busImage = busImage;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }
    
}
