/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.util;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author User
 * @param <T>
 */
public interface DaoService<T> {
    
    /**s
     *
     * @param query
     * @param data
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    
    T fetch(String query, int data) throws SQLException, ClassNotFoundException;
    
    List<T> fetchAll() throws SQLException, ClassNotFoundException;
    
    int addData(T t) throws SQLException, ClassNotFoundException;
    
    int updateData(T t) throws SQLException, ClassNotFoundException;
    
}
