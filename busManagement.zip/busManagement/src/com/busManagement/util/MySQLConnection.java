/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class MySQLConnection {
    private static final String DBMS_TYPE = "mysql";
    private static final String INSTANCE_CONNECTION_NAME = "busdb-335912:us-central1:busdb";
//    private static final String IP_NAME = "34.68.222.5";
    private static final String IP_NAME = "localhost";
    private static final String PORT_NAME = "3306";
    private static final String DB_USER = "root";
//    private static final String DB_PASS = "12345";
    private static final String DB_PASS = "root";
    private static final String DB_NAME = "busdb";
    
    
    private static final String JDBC_URL = String.format("jdbc:%s://%s:%s/%s", DBMS_TYPE, IP_NAME, PORT_NAME, DB_NAME);
        
    public static Connection getConnection() throws SQLException, ClassNotFoundException {
//        HikariConfig config = new HikariConfig();
//        
//        config.setJdbcUrl(String.format("jdbc:mysql:///%s", DB_NAME));
//        config.setUsername(DB_USER);
//        config.setPassword(DB_PASS);
//        config.addDataSourceProperty("socketFactory", "com.google.cloud.sql.mysql.SocketFactory");
//        config.addDataSourceProperty("cloudSqlInstance", INSTANCE_CONNECTION_NAME);
//        
//        config.addDataSourceProperty("ipTypes", "PUBLIC,PRIVATE"); 
//        
//        config.setMaximumPoolSize(5);
//        config.setMinimumIdle(5);
//        
//        config.setConnectionTimeout(10000); // 10 seconds
//        
//        config.setIdleTimeout(60000); // 10 minutes
//        
//        config.setMaxLifetime(180000); // 30 minutes
//        
//        DataSource pool = new HikariDataSource(config);
//        
//        return pool.getConnection();
//          System.out.println("Hi from MySQLDriver");
          Class.forName("com.mysql.cj.jdbc.Driver"); // MYSQL Version 8
          Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
          connection.setAutoCommit(false);
          
          return connection;
    }    
}
