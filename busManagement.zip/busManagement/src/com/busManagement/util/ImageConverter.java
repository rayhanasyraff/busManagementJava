/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.util;

import java.awt.Graphics;
import java.sql.Blob;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
/**
 *
 * @author rayha
 */
public class ImageConverter {
    public static BufferedImage blobToImage(Blob blob) throws IOException, SQLException {       
        InputStream input = blob.getBinaryStream();
        return ImageIO.read(input);  
    }
    
    public static Blob imageToBlob(BufferedImage image) throws IOException, SQLException, ClassNotFoundException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "jpg", baos);
        byte[] bytes = baos.toByteArray();
        Connection connection = MySQLConnection.getConnection();        
        Blob blob = connection.createBlob();
        blob.setBytes(1, bytes);
        return blob;        
    }
    
    public static BufferedImage iconToImage(ImageIcon icon) {
        BufferedImage bi = new BufferedImage(
        icon.getIconWidth(),
        icon.getIconHeight(),
        BufferedImage.TYPE_INT_RGB);
        Graphics g = bi.createGraphics();
        // paint the Icon to the BufferedImage.
        icon.paintIcon(null, g, 0,0);
        g.dispose();
        return bi;
    }
}
