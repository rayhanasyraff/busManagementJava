/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Booking;
import com.busManagement.entity.Discount;
import com.busManagement.entity.Payment;
import com.busManagement.util.DaoService;
import com.busManagement.util.MySQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rayha
 */
public class PaymentDaoImpl implements DaoService<Payment> {  

    @Override
    public Payment fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Payment payment = new Payment();
        query += " WHERE paymentId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {                        
                        BookingDaoImpl bookingDao = new BookingDaoImpl();
                        query = "SELECT * FROM booking";
                        Booking booking = bookingDao.fetch(query, rs.getInt("bookingId"));
                        
                        DiscountDaoImpl discountDao = new DiscountDaoImpl();
                        query = "SELECT * FROM discount";
                        Discount discount = discountDao.fetch(query, rs.getInt("discountId"));                       
                        
                        payment.setId(rs.getInt("paymentId"));
                        payment.setBooking(booking);
                        payment.setDiscount(discount);
                    }
                }            
            }
        }
        return payment;        
    }    
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Payment> payments = new ArrayList<>();
        String query = "SELECT * FROM payment";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Payment payment = fetch(query, rs.getInt("paymentId"));
                        payments.add(payment);
                    }
                }
            }
        }
        return payments;
    }
    
    @Override
    public int addData(Payment payment) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO payment VALUES(?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {                
                ps.setInt(1, payment.getId());
                ps.setInt(2, payment.getBooking().getId());
                ps.setInt(3, payment.getDiscount().getId());         

                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }
    
    @Override
    public int updateData(Payment payment) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE payment SET bookingId = ?, discountId = ? WHERE paymentId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, payment.getBooking().getId());
                ps.setInt(2, payment.getDiscount().getId());    
                ps.setInt(3, payment.getId());                
                
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }
}