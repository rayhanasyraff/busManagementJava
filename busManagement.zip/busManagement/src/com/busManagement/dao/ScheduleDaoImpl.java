/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Bus;
import com.busManagement.entity.Location;
import com.busManagement.entity.Schedule;
import com.busManagement.util.DaoService;
import com.busManagement.util.MySQLConnection;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalTime;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;

public class ScheduleDaoImpl implements DaoService<Schedule> {

    @Override
    public Schedule fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Schedule schedule = new Schedule();
        query += " WHERE scheduleId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        BusDaoImpl busDao = new BusDaoImpl();
                        query = "SELECT * FROM bus";
                        Bus bus = busDao.fetch(query, rs.getInt("busId"));

                        LocationDaoImpl locationDao = new LocationDaoImpl();
                        query = "SELECT * FROM location";
                        Location source = locationDao.fetch(query, rs.getInt("source"));
                        Location destination = locationDao.fetch(query, rs.getInt("destination"));
                        
                        LocalDate date = rs.getObject("date", LocalDate.class);
                        LocalTime time = rs.getObject("time", LocalTime.class);
                        
                        schedule.setId(rs.getInt("scheduleId"));
                        schedule.setBus(bus);
                        schedule.setSource(source);
                        schedule.setDestination(destination);
                        schedule.setTravelDuration(rs.getInt("travelDuration"));
                        schedule.setDescription(rs.getString("description"));
                        schedule.setDate(date);
                        schedule.setTime(time);
                        schedule.setFare(rs.getDouble("fare"));
                        schedule.setAvailable(rs.getInt("available"));
                    }
                }            
            }
        }
        return schedule;        
    }      
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Schedule> schedules = new ArrayList<>();
        String query = "SELECT * FROM schedule";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {                    
                        Schedule schedule = fetch(query, rs.getInt("scheduleId"));
                        schedules.add(schedule);
                    }
                }
            }
        }
        return schedules;
    }
    
    @Override
    public int addData(Schedule schedule) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO schedule VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {               
                Date date = Date.valueOf(schedule.getDate());
                Time time = Time.valueOf(schedule.getTime());
                
                ps.setInt(1, schedule.getId());
                ps.setInt(2, schedule.getBus().getId());
                ps.setInt(3, schedule.getSource().getId());
                ps.setInt(4, schedule.getDestination().getId());
                ps.setInt(5, schedule.getTravelDuration());
                ps.setString(6, schedule.getDescription());
                ps.setDate(7, date);
                ps.setTime(8, time);
                ps.setDouble(9, schedule.getFare());
                ps.setInt(10, schedule.getAvailable());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }
    
    @Override
    public int updateData(Schedule schedule) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE bus SET busId = ?, source = ?, destination = ?, travelDuration = ?, description = ?, date = ?, time = ?, fare = ?, available = ? WHERE scheduleId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                Date date = Date.valueOf(schedule.getDate());
                Time time = Time.valueOf(schedule.getTime());
                
                ps.setInt(1, schedule.getBus().getId());
                ps.setInt(2, schedule.getSource().getId());
                ps.setInt(3, schedule.getDestination().getId());
                ps.setInt(4, schedule.getTravelDuration());
                ps.setString(5, schedule.getDescription());
                ps.setDate(6, date);
                ps.setTime(7, time);
                ps.setDouble(8, schedule.getFare());
                ps.setInt(9, schedule.getAvailable());
                ps.setInt(10, schedule.getId());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }  
}