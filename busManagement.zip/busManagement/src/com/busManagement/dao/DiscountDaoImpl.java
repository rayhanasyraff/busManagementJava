/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Discount;
import com.busManagement.util.DaoService;
import com.busManagement.util.MySQLConnection;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author User
 */
public class DiscountDaoImpl implements DaoService<Discount> {

    @Override
    public Discount fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Discount discount = new Discount();
        query += " WHERE discountId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        discount.setId(rs.getInt("discountId"));
                        discount.setName(rs.getString("name"));
                        discount.setAmount(rs.getDouble("amount"));
                    }
                }
            }
        }
        return discount;        
    }  
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Discount> discounts = new ArrayList<>();
        String query = "SELECT * FROM discount";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Discount discount = fetch(query, rs.getInt("discountId"));
                        discounts.add(discount);
                    }
                }
            }
        }
        return discounts;
    }
    
    @Override
    public int addData(Discount discount) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO discount VALUES( ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, discount.getId());
                ps.setString(2, discount.getName());
                ps.setDouble(3, discount.getAmount());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }
        }
        return result;
    }
    
    @Override
    public int updateData(Discount discount) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE discount SET name = ?, amount = ? WHERE discountId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setString(1, discount.getName());
                ps.setDouble(2, discount.getAmount());
                ps.setInt(3, discount.getId());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }
        }
        return result;
    }    
    
}