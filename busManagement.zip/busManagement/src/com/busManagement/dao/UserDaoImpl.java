/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Account;
import com.busManagement.entity.User;
import com.busManagement.util.DaoService;
import com.busManagement.util.ImageConverter;
import com.busManagement.util.MySQLConnection;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Blob;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class UserDaoImpl implements DaoService<User> {  

    @Override
    public User fetch(String query, int data) throws SQLException, ClassNotFoundException {
        User user = new User();
        query += " WHERE userId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {                        
                        AccountDaoImpl accountDao = new AccountDaoImpl();
                        query = "SELECT * FROM account";
                        Account account = accountDao.fetch(query, rs.getInt("accountId"));
                        
                        BufferedImage profilePicture = ImageConverter.blobToImage(rs.getBlob("profilePicture"));                   
                        
                        user.setId(rs.getInt("userId"));
                        user.setEmail(rs.getString("email"));
                        user.setUsername(rs.getString("username"));
                        user.setPassword(rs.getString("password"));
                        user.setPhone(rs.getString("phone"));
                        user.setAddress(rs.getString("address"));
                        user.setProfilePicture(profilePicture);
                        user.setRole(rs.getInt("role"));
                        user.setAccount(account);
                    }
                } catch (IOException ex) {
                    Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return user;        
    }    
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM user";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        User user = fetch(query, rs.getInt("userId"));
                        users.add(user);
                    }
                }
            }
        }
        return users;
    }
    
    @Override
    public int addData(User user) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO user VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                Blob profilePicture = ImageConverter.imageToBlob(user.getProfilePicture());
                
                ps.setInt(1, user.getId());
                ps.setString(2, user.getEmail());
                ps.setString(3, user.getUsername());
                ps.setString(4, user.getPassword());
                ps.setString(5, user.getPhone());
                ps.setString(6, user.getAddress());          
                ps.setBlob(7, profilePicture);
                ps.setInt(8, user.getRole());
                ps.setInt(9, user.getAccount().getId());
                
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            } catch (IOException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result;
    }
    
    @Override
    public int updateData(User user) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE user SET email = ?, username = ?, password = ?, phone = ?, address = ?, profilePicture = ?, role = ?, accountId = ? WHERE userId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                
                Blob profilePicture = ImageConverter.imageToBlob(user.getProfilePicture());
                
                ps.setString(1, user.getEmail());
                ps.setString(2, user.getUsername());
                ps.setString(3, user.getPassword());
                ps.setString(4, user.getPhone());
                ps.setString(5, user.getAddress());          
                ps.setBlob(6, profilePicture);
                ps.setInt(7, user.getRole());
                ps.setInt(8, user.getAccount().getId());
                ps.setInt(9, user.getId());
                
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            } catch (IOException ex) {
                Logger.getLogger(UserDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result;
    }
}