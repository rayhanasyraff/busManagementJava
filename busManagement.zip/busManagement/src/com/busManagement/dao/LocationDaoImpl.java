/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Location;
import com.busManagement.util.DaoService;
import com.busManagement.util.MySQLConnection;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LocationDaoImpl implements DaoService<Location> {

    @Override
    public Location fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Location location = new Location();
        query += " WHERE locationId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        location.setId(rs.getInt("locationId"));
                        location.setName(rs.getString("name"));
                        location.setCity(rs.getString("city"));
                        location.setPhone(rs.getString("phone"));
                        location.setAddress1(rs.getString("address1"));
                        location.setAddress2(rs.getString("address2"));
                        location.setState(rs.getString("state"));
                        location.setPostalCode(rs.getString("postalCode"));
                    }
                }            
            }
        }
        return location;        
    }      
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Location> locations = new ArrayList<>();
        String query = "SELECT * FROM location";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {                    
                        Location location = fetch(query, rs.getInt("locationId"));
                        locations.add(location);
                    }
                }
            }
        }
        return locations;
    }
    
    @Override
    public int addData(Location location) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO location VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, location.getId());
                ps.setString(2, location.getName());
                ps.setString(3, location.getCity());
                ps.setString(4, location.getPhone());
                ps.setString(5, location.getAddress1());
                ps.setString(6, location.getAddress2());
                ps.setString(7, location.getState());
                ps.setString(8, location.getPostalCode());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }
    
    @Override
    public int updateData(Location location) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE bus SET name = ?, city = ?, phone = ?, address1 = ?, address2 = ?, state = ?, postalCode = ? WHERE locationId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setString(1, location.getName());
                ps.setString(2, location.getCity());
                ps.setString(3, location.getPhone());
                ps.setString(4, location.getAddress1());
                ps.setString(5, location.getAddress2());
                ps.setString(6, location.getState());
                ps.setString(7, location.getPostalCode());
                ps.setInt(8, location.getId());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }  
}