/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Company;
import com.busManagement.util.DaoService;
import com.busManagement.util.MySQLConnection;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class CompanyDaoImpl implements DaoService<Company> {
    
    @Override
    public Company fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Company company = new Company();
        query += " WHERE companyId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        company.setId(rs.getInt("companyId"));
                        company.setName(rs.getString("name"));
                        company.setAddress(rs.getString("address"));
                        company.setDescription(rs.getString("description"));
                    }
                }            
            }
        }
        return company;        
    }      
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Company> companies = new ArrayList<>();
        String query = "SELECT * FROM company";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {                    
                        Company company = fetch(query, rs.getInt("companyId"));
                        companies.add(company);
                    }
                }
            }
        }
        return companies;
    }
    
    @Override
    public int addData(Company company) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO company VALUES(?, ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {               
                ps.setInt(1, company.getId());
                ps.setString(2, company.getName());
                ps.setString(3, company.getAddress());
                ps.setString(4, company.getDescription());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }
    
    @Override
    public int updateData(Company company) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE company SET name = ?, address = ?, description = ? WHERE companyId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {                
                ps.setString(1, company.getName());
                ps.setString(2, company.getAddress());
                ps.setString(3, company.getDescription());
                ps.setInt(4, company.getId());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }  
}
