/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Account;
import com.busManagement.util.DaoService;
import com.busManagement.util.MySQLConnection;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class AccountDaoImpl implements DaoService<Account> { 
    
    @Override
    public Account fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Account account = new Account();
        query += " WHERE accountId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        account.setId(rs.getInt("accountId"));
                        account.setName(rs.getString("name"));
                        account.setMonth(rs.getInt("month"));
                        account.setYear(rs.getInt("year"));
                        account.setCvv(rs.getString("cvv"));
                        account.setBalance(rs.getDouble("balance"));
                    }
                }
            }
        }
        return account;        
    }
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Account> accounts = new ArrayList<>();
        String query = "SELECT * FROM account";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Account account = fetch(query, rs.getInt("accountId"));
                        accounts.add(account);
                    }
                }
            }
        }
        return accounts;
    }
    
    @Override
    public int addData(Account account) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO Account VALUES( ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, account.getId());
                ps.setString(2, account.getName());
                ps.setInt(3, account.getMonth());
                ps.setInt(4, account.getYear());
                ps.setString(5, account.getCvv());
                ps.setDouble(6, account.getBalance());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }
        }
        return result;
    }
    
    @Override
    public int updateData(Account account) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE account SET name = ?, month = ?, year = ?, cvv = ?, balance = ? WHERE accountId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setString(1, account.getName());
                ps.setInt(2, account.getMonth());
                ps.setInt(3, account.getYear());
                ps.setString(4, account.getCvv());
                ps.setDouble(5, account.getBalance());
                ps.setInt(6, account.getId());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }
        }
        return result;
    }   
}