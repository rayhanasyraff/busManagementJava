/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Bus;
import com.busManagement.entity.Company;
import com.busManagement.util.DaoService;
import com.busManagement.util.ImageConverter;
import com.busManagement.util.MySQLConnection;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Blob;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class BusDaoImpl implements DaoService<Bus> {

    @Override
    public Bus fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Bus bus = new Bus();
        query += " WHERE busId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        CompanyDaoImpl companyDao = new CompanyDaoImpl();
                        query = "SELECT * FROM company";
                        Company company = companyDao.fetch(query, rs.getInt("companyId"));
                        
                        BufferedImage busImage = ImageConverter.blobToImage(rs.getBlob("busImage"));    

                        bus.setId(rs.getInt("busId"));
                        bus.setName(rs.getString("name"));
                        bus.setType(rs.getString("type"));
                        bus.setCompany(company);
                        bus.setBusImage(busImage);
                        bus.setTotalSeats(rs.getInt("totalSeats"));
                        bus.setAvailableSeats(rs.getInt("availableSeats"));
                    }
                } catch (IOException ex) {
                    Logger.getLogger(BusDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return bus;        
    }      
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Bus> buses = new ArrayList<>();
        String query = "SELECT * FROM bus";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {                    
                        Bus bus = fetch(query, rs.getInt("busId"));
                        buses.add(bus);
                    }
                }
            }
        }
        return buses;
    }
    
    @Override
    public int addData(Bus bus) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO bus VALUES(?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                Blob busImage = ImageConverter.imageToBlob(bus.getBusImage());
                
                ps.setInt(1, bus.getId());
                ps.setString(2, bus.getName());
                ps.setString(3, bus.getType());
                ps.setInt(4, bus.getCompany().getId());
                ps.setBlob(5, busImage);
                ps.setInt(6, bus.getTotalSeats());
                ps.setInt(7, bus.getAvailableSeats());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            } catch (IOException ex) {
                Logger.getLogger(BusDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result;
    }
    
    @Override
    public int updateData(Bus bus) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE bus SET name = ?, type = ?, company = ?, image = ?, totalSeats = ?, availableSeats = ? WHERE busId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                Blob busImage = ImageConverter.imageToBlob(bus.getBusImage());              
                
                ps.setString(1, bus.getName());
                ps.setString(2, bus.getType());
                ps.setInt(3, bus.getCompany().getId());
                ps.setBlob(4, busImage);
                ps.setInt(5, bus.getTotalSeats());
                ps.setInt(6, bus.getAvailableSeats());
                ps.setInt(7, bus.getId());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            } catch (IOException ex) {
                Logger.getLogger(BusDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result;
    }  
}