/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.dao;

import com.busManagement.entity.Booking;
import com.busManagement.entity.Schedule;
import com.busManagement.entity.User;
import com.busManagement.util.DaoService;
import com.busManagement.util.MySQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rayha
 */
public class BookingDaoImpl implements DaoService<Booking> {  

    @Override
    public Booking fetch(String query, int data) throws SQLException, ClassNotFoundException {
        Booking booking = new Booking();
        query += " WHERE bookingId = ?";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, data);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {                        
                        UserDaoImpl userDao = new UserDaoImpl();
                        query = "SELECT * FROM user";
                        User user = userDao.fetch(query, rs.getInt("userId"));
                        
                        ScheduleDaoImpl scheduleDao = new ScheduleDaoImpl();
                        query = "SELECT * FROM schedule";
                        Schedule schedule = scheduleDao.fetch(query, rs.getInt("scheduleId"));                       
                        
                        booking.setId(rs.getInt("bookingId"));
                        booking.setSchedule(schedule);
                        booking.setUser(user);
                        booking.setNoOfAdults(rs.getInt("noOfAdults"));
                        booking.setNoOfChildrens(rs.getInt("noOfChildrens"));
                        booking.setStatus(rs.getInt("status"));
                    }
                }            
            }
        }
        return booking;        
    }    
    
    @Override
    public List fetchAll() throws SQLException, ClassNotFoundException {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT * FROM booking";
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Booking booking = fetch(query, rs.getInt("bookingId"));
                        bookings.add(booking);
                    }
                }
            }
        }
        return bookings;
    }
    
    @Override
    public int addData(Booking booking) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "INSERT INTO booking VALUES(?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {                
                ps.setInt(1, booking.getId());
                ps.setInt(2, booking.getSchedule().getId());
                ps.setInt(3, booking.getUser().getId());
                ps.setInt(4, booking.getNoOfAdults());
                ps.setInt(5, booking.getNoOfChildrens());
                ps.setInt(6, booking.getStatus());          

                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }
    
    @Override
    public int updateData(Booking booking) throws SQLException, ClassNotFoundException {
        int result = 0;
        String query = "UPDATE booking SET scheduleId = ?, userId = ?, noOfAdults = ?, noOfChildrens = ?, status = ? WHERE bookingId = ?";
        
        try (Connection connection = MySQLConnection.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, booking.getSchedule().getId());
                ps.setInt(2, booking.getUser().getId());
                ps.setInt(3, booking.getNoOfAdults());
                ps.setInt(4, booking.getNoOfChildrens());
                ps.setInt(5, booking.getStatus());
                ps.setInt(6, booking.getId());                
                
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }        
        }
        return result;
    }
}
