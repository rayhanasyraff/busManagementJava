/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.model;

import com.busManagement.entity.Schedule;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author rayha
 */
public class ScheduleTableModel extends AbstractTableModel {
    private List<Schedule> schedules;
    private final String[] COLUMNS = {"ID", "BUS ID", "SOURCE", "DESTINATION", "TRAVEL DURATION", "DESCRIPTION", "DATE", "TIME", "FARE", "AVAILABLE"};

    public ScheduleTableModel(List<Schedule> schedules) {
        this.schedules = schedules;
    }
    
    @Override
    public int getRowCount() {
        return schedules.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return switch (columnIndex) {
            case 0 -> schedules.get(rowIndex).getId();
            case 1 -> schedules.get(rowIndex).getBus().getId();
            case 2 -> schedules.get(rowIndex).getSource().getId();
            case 3 -> schedules.get(rowIndex).getDestination().getId();
            case 4 -> schedules.get(rowIndex).getTravelDuration();
            case 5 -> schedules.get(rowIndex).getDescription();
            case 6 -> schedules.get(rowIndex).getDate();
            case 7 -> schedules.get(rowIndex).getTime();
            case 8 -> schedules.get(rowIndex).getFare();
            case 9 -> schedules.get(rowIndex).getAvailable();
            default -> "";
        };
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (getValueAt(0, columnIndex) != null) {
            return getValueAt(0, columnIndex).getClass();
        }
        return Object.class;
    }
}
