/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.model;

import com.busManagement.entity.Location;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author rayha
 */
public class LocationTableModel extends AbstractTableModel {
    private List<Location> locations;
    private final String[] COLUMNS = {"ID", "NAME", "CITY", "PHONE NO", "ADDRESS 1", "ADDRESS 2", "STATE", "POSTAL CODE"};

    public LocationTableModel(List<Location> locations) {
        this.locations = locations;
    }
    
    @Override
    public int getRowCount() {
        return locations.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return switch (columnIndex) {
            case 0 -> locations.get(rowIndex).getId();
            case 1 -> locations.get(rowIndex).getName();
            case 2 -> locations.get(rowIndex).getCity();
            case 3 -> locations.get(rowIndex).getPhone();
            case 4 -> locations.get(rowIndex).getAddress1();
            case 5 -> locations.get(rowIndex).getAddress2();
            case 6 -> locations.get(rowIndex).getState();
            case 7 -> locations.get(rowIndex).getPostalCode();
            default -> "";
        };
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (getValueAt(0, columnIndex) != null) {
            return getValueAt(0, columnIndex).getClass();
        }
        return Object.class;
    }
}
