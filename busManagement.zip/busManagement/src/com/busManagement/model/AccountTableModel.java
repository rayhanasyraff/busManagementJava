/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.model;

import com.busManagement.entity.Account;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author rayha
 */
public class AccountTableModel extends AbstractTableModel {
    private List<Account> accounts;
    private final String[] COLUMNS = {"ID", "EMAIL", "USERNAME", "PASSWORD", "PHONE", "ADDRESS", "BANK", "ROLE", "ACCOUNT NUMBER"};

    public AccountTableModel(List<Account> accounts) {
        this.accounts = accounts;
    }
    
    @Override
    public int getRowCount() {
        return accounts.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return switch (columnIndex) {
            case 0 -> accounts.get(rowIndex).getId();
            case 1 -> accounts.get(rowIndex).getName();
            case 2 -> accounts.get(rowIndex).getMonth();
            case 3 -> accounts.get(rowIndex).getYear();
            case 4 -> accounts.get(rowIndex).getCvv();
            case 5 -> accounts.get(rowIndex).getBalance();
            default -> "";
        };
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (getValueAt(0, columnIndex) != null) {
            return getValueAt(0, columnIndex).getClass();
        }
        return Object.class;
    }
}
