/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.model;

import com.busManagement.entity.Payment;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author rayha
 */
public class PaymentTableModel extends AbstractTableModel {
    private List<Payment> payments;
    private final String[] COLUMNS = {"ID", "BOOKING ID", "DISCOUNT"};

    public PaymentTableModel(List<Payment> payments) {
        this.payments = payments;
    }
    
    @Override
    public int getRowCount() {
        return payments.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return switch (columnIndex) {
            case 0 -> payments.get(rowIndex).getId();
            case 1 -> payments.get(rowIndex).getBooking().getId();
            case 2 -> payments.get(rowIndex).getDiscount().getId();
            default -> "";
        };
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (getValueAt(0, columnIndex) != null) {
            return getValueAt(0, columnIndex).getClass();
        }
        return Object.class;
    }
}
