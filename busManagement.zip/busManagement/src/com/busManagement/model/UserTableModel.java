/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.model;

import com.busManagement.entity.User;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author rayha
 */
public class UserTableModel extends AbstractTableModel {
    private final List<User> users;
    private final String[] COLUMNS = {"ID", "EMAIL", "USERNAME", "PASSWORD", "PHONE", "ADDRESS", "ROLE", "ACCOUNT NUMBER", "BALANCE (RM)"};

    public UserTableModel(List<User> users) {
        this.users = users;
    }
    
    @Override
    public int getRowCount() {
        return users.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return switch (columnIndex) {
            case 0 -> users.get(rowIndex).getId();
            case 1 -> users.get(rowIndex).getEmail();
            case 2 -> users.get(rowIndex).getUsername();
            case 3 -> users.get(rowIndex).getPassword();
            case 4 -> users.get(rowIndex).getPhone();
            case 5 -> users.get(rowIndex).getAddress();
            case 6 -> users.get(rowIndex).getRole() == 0 ? "Passenger" : "Admin";
            case 7 -> users.get(rowIndex).getAccount().getId();
            case 8 -> users.get(rowIndex).getAccount().getBalance();                
            default -> "";
        };
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (getValueAt(0, columnIndex) != null) {
            return getValueAt(0, columnIndex).getClass();
        }
        return Object.class;
    }
}