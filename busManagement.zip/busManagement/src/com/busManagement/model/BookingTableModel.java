/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busManagement.model;

import com.busManagement.entity.Booking;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author rayha
 */
public class BookingTableModel extends AbstractTableModel {
    private List<Booking> bookings;
    private final String[] COLUMNS = {"ID", "SCHEDULE ID", "USER ID", "NO OF ADULTS", "NO OF CHILDRENS", "STATUS"};

    public BookingTableModel(List<Booking> bookings) {
        this.bookings = bookings;
    }
    
    @Override
    public int getRowCount() {
        return bookings.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return switch (columnIndex) {
            case 0 -> bookings.get(rowIndex).getId();
            case 1 -> bookings.get(rowIndex).getSchedule().getId();
            case 2 -> bookings.get(rowIndex).getUser().getId();
            case 3 -> bookings.get(rowIndex).getNoOfAdults();
            case 4 -> bookings.get(rowIndex).getNoOfChildrens();
            case 5 -> bookings.get(rowIndex).getStatus();
            default -> "";
        };
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (getValueAt(0, columnIndex) != null) {
            return getValueAt(0, columnIndex).getClass();
        }
        return Object.class;
    }
}
